player_STR = 0
player_INT = 0
player_DEX = 0
player_HP = 100
EXP = 0
choose = 0
player = ''
storys = 0
storylist = [1, 2, 3, 4, 5]
player_action = ''
enemy = ''
exp_earnedlist = 0

#players previous actions
PPA = []
PPA_attack = 0
PPA_block = 0
PPA_dodge = 0
PPA_magic = 0
TPA = []
history_current = []
history_previous = []